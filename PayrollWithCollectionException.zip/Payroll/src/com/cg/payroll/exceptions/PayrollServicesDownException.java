package com.cg.payroll.exceptions;

@SuppressWarnings("serial")
public class PayrollServicesDownException extends Exception {
	
}
